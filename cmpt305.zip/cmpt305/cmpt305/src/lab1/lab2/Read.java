package package1.lab2;

import package1.package1.CsvParser;
import package1.lab2.PropertyList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class Read {
    public static void main(String[] args) {
        // create scanner
        Scanner scanner = new Scanner(System.in);
        System.out.print("CSV filename: ");
        String csvFileName = scanner.nextLine();
        // try to parse filename
        PropertyList pList;
        try { // FIRST LINE --------------------------------------------------------------------
            pList = new PropertyList(readData(csvFileName));

            List<Integer> aList = pList.allStats();
            //print
            System.out.println("n = " + aList.get(0));
            System.out.println("min = $" + aList.get(1));
            System.out.println("max = $" + aList.get(2));
            System.out.println("range = $" + aList.get(3));
            System.out.println("mean = $" + aList.get(4));
            System.out.println("median = $" + aList.get(5));

            System.out.print("Find a property assessment by account number: ");
            try { // SECOND LINE -------------------------------------------------------------
                int accountNum = Integer.parseInt(scanner.nextLine());
                List<String> bList = pList.accStats(accountNum);
                //print
                if (!bList.getFirst().equals("-1")){
                    System.out.println("Account Number = " + bList.get(0));
                    System.out.println("Address = " + bList.get(1));
                    System.out.println("Assessed value = " + bList.get(2));
                    System.out.println("Assessment class = " + bList.get(3));
                    System.out.println("Neighborhood = " + bList.get(4));
                    System.out.println("Location = " + bList.get(5));

                } else {
                    System.out.println("Property is not found");
                }

            } catch (NumberFormatException e){
                System.out.println("Invalid account number");
            }

            System.out.print("Find statistics by neighborhood: ");
            //try { // THIRD LINE -----------------------------------------------------------
                String neistr = scanner.nextLine();
                List<Integer> cList = pList.neiStats(neistr);
                //print
                if (cList.getFirst() != -1){
                    System.out.println("n = " + cList.get(0));
                    System.out.println("min = $" + cList.get(1));
                    System.out.println("max = $" + cList.get(2));
                    System.out.println("range = $" + cList.get(3));
                    System.out.println("mean = $" + cList.get(4));
                    System.out.println("median = $" + cList.get(5));

                } else {
                    System.out.println("Neighborhood is not found");
                }
            //} //catch (){
              //  System.out.println("Invalid neighborhood name");
            //}

        } catch (IOException e) {
            System.err.println("Error: can't open file " + csvFileName);
        }


    }

    private static String[][] readData(String csvFileName) throws IOException {
        String[][] data;
        int currentIndex = 0;
        // Try-with-resources statement to create a stream to read the CSV file. Automatically closes the resource.
        try (BufferedReader reader = Files.newBufferedReader(Path.of(csvFileName))) {
            // Skip the header - this assumes the first line is a header
            reader.readLine();

            // Create 2D array to store all rows of data as String
            int initialSize = 100;
            data = new String[initialSize][];

            // Read the file line by line and store all rows into a 2D array
            String record;
            while ((record = reader.readLine()) != null) {
                // Parse the record into fields
                // A simple CSV line with fields that are not surrounded by double-quotes,
                // and all commas acting as separators, can be split using the String.plit() method.
                // String[] values = record.split(",");
                // Otherwise, a more general CSV parsing is required:
                String[] values = CsvParser.parseCSVLine(record);

                // Check if the array is full
                if (currentIndex == data.length)
                // Array is full, create and copy all values to a larger array
                {
                    data = Arrays.copyOf(data, data.length * 2);
                }

                data[currentIndex++] = values;
            }
        }

        // Remove empty rows in the array and return it
        return Arrays.copyOf(data, currentIndex);
    }
    private static void printList(String[][] data){

    }

}
