package package1.lab2;

import java.util.*;

public class PropertyList {
    public List<Integer> accountNum = new ArrayList<>();
    public List<String> neighborhood = new ArrayList<>();
    private List<String> address = new ArrayList<>();
    private List<Integer> assesedValue = new ArrayList<>();
    private List<String> assessmentClass = new ArrayList<>();
    private List<String> location = new ArrayList<>();
    private List<String> ward = new ArrayList<>();

    public PropertyList(String[][] data){
        for (String[] rows : data){
        accountNum.add(Integer.parseInt(rows[0]));
        neighborhood.add(rows[5]);
        assesedValue.add(Integer.parseInt(rows[7]));
        assessmentClass.add(rows[10]+" "+rows[13]+" "+rows[11]+" "+rows[14]+" "+rows[12]+" "+rows[15]);
        location.add(rows[18]);
        address.add(rows[2]+" "+rows[3]);
        ward.add(rows[6]);
        }
    }

    public List<Integer> allStats(){
        List<Integer> allS = new ArrayList<>();
        int min = -1;
        int max = -1;
        long total = 0;
        for (int num : assesedValue){
            total = total + num;
            if (max == -1 && min == -1){
                max = num;
                min = num;
            } else if (num > max){
                max = num;
            } else if (num < min) {
                min = num;
            }
        }

        allS.add(accountNum.toArray().length);
        allS.add(min);
        allS.add(max);
        allS.add(max-min);
        allS.add((int)((double)total/(double) accountNum.toArray().length));
        //MEDIAN???
        allS.add(findMedian(assesedValue, max, min));
        return allS;
    }

    public List<String> accStats(int anum){
        List<String> aList = new ArrayList<>();
        int count = 0;
        for (int num : accountNum){
            if (anum == num){
                aList.add(""+num); // Fix Stuff
                aList.add(address.get(count));
                aList.add("$"+assesedValue.get(count));
                aList.add(assessmentClass.get(count));
                aList.add(neighborhood.get(count)+"("+ward.get(count)+")");
                aList.add(location.get(count));
                return aList;
            }
            count++;
        }
        aList.add("-1");
        return aList;
    }
    public List<Integer> neiStats(String neigh){
        List<Integer> aList = new ArrayList<>();
        List<Integer> bList = new ArrayList<>();
        int max = -1;
        int min = -1;
        long total = 0; // num total
        int count = 0; // var count
        int tally = 0; // item tally
        for (String name : neighborhood){
            if (neigh.equalsIgnoreCase(name)){
                int num = assesedValue.get(count);
                tally++;
                total = total + num;
                if (max == -1 && min == -1){
                    max = num;
                    min = num;
                } else if (num > max){
                    max = num;
                } else if (num < min) {
                    min = num;
                }
                bList.add(num);
            }
            count++;
        }
        if (tally == 0){
            aList.add(-1);
            return aList;
        }
        aList.add(tally);
        aList.add(min);
        aList.add(max);
        aList.add(max-min);
        aList.add((int)((double)total/(double)tally));
        aList.add(findMedian(bList, max, min));
        return aList;
    }
    private int findMedian(List<Integer> array, int max, int min){
        Object[] array2 = array.toArray();
        //sort!?
        Arrays.sort(array2);
        if (array2.length % 2 == 0){
            return((int)array2[(int)(array2.length/2+1)]+(int)array2[(int)(array2.length/2)])/2;
        } else {
        return (int)array2[(int)(array2.length/2+1)];
        }
    }
}
