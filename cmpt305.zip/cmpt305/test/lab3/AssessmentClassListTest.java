package lab3;

import lab2.PropertyAssessments;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class AssessmentClassListTest {

    PropertyAssessments a;
    PropertyAssessments b;
    PropertyAssessments c;

    @BeforeEach
    void setUp() throws IOException {
        a = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        b = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        c = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        a.buildAssess("residential");
        b.buildAssess("commercial");
        c.buildAssess("residential");
    }

    @Test
    void number() {
        assertEquals(a.assessList.number(), c.assessList.number());
        assertEquals(16 ,b.assessList.number());
    }

    @Test
    void max() {
        assertEquals(18597500, a.assessList.max());
    }

    @Test
    void min() {
        assertEquals(3000, a.assessList.min());
    }

    @Test
    void range() {
        assertEquals(18594500, a.assessList.range());
    }

    @Test
    void mean() {
        assertEquals(944638, a.assessList.mean());
    }

    @Test
    void median() {
        assertEquals(439500, a.assessList.median());
    }

    @Test
    void testToString() {
        assertEquals(c.assessList.toString(), a.assessList.toString());
    }

    @Test
    void testEquals() {
        assertTrue(c.assessList.equals(c.assessList));
        assertFalse(a.assessList.equals(b.assessList));
    }

    @Test
    void testHashCode() {
        assertTrue(a.assessList.hashCode() == c.assessList.hashCode());
        assertFalse(a.assessList.hashCode() == b.assessList.hashCode());
    }
}