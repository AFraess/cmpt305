package lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class NeighborhoodAssessmentsTest {

    PropertyAssessments a;
    PropertyAssessments b;
    PropertyAssessments c;

    @BeforeEach
    void setUp() throws IOException {
        a = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        b = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        c = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        a.buildNeighbor("Stillwater");
        b.buildNeighbor("eaux Claires");
        c.buildNeighbor("stILLWATER");
    }

    @Test
    void number() {
        assertEquals(a.neighborList.number(), c.neighborList.number());
        assertEquals(1 ,b.neighborList.number());
    }

    @Test
    void max() {
        assertEquals(380000, a.neighborList.max());
    }

    @Test
    void min() {
        assertEquals(167000, a.neighborList.min());
    }

    @Test
    void range() {
        assertEquals(213000, a.neighborList.range());
    }

    @Test
    void mean() {
        assertEquals(273500, a.neighborList.mean());
    }

    @Test
    void median() {
        assertEquals(273500, a.neighborList.median());
    }

    @Test
    void testToString() {
        assertEquals(c.neighborList.toString(), a.neighborList.toString());
    }

    @Test
    void testEquals() {
        assertTrue(c.neighborList.equals(c.neighborList));
        assertFalse(a.neighborList.equals(b.neighborList));
    }

    @Test
    void testHashCode() {
        assertTrue(a.neighborList.hashCode() == c.neighborList.hashCode());
        assertFalse(a.neighborList.hashCode() == b.neighborList.hashCode());
    }
}