package lab2;

import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class PropertyAssessmentsTest {

    PropertyAssessments a;
    PropertyAssessments b;
    PropertyAssessments c;

    @org.junit.jupiter.api.BeforeEach
    void setUp() throws IOException {
        a = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        b = new PropertyAssessments("Property_Assessment_Data_2026_Test.csv");
        c = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        try {
            PropertyAssessments d = new PropertyAssessments("abcd");
        } catch (IOException e){

        }
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void number() {
        assertEquals(a.number(), c.number());
        assertEquals(39 ,b.number());
    }

    @org.junit.jupiter.api.Test
    void max() {
        assertEquals(18597500, a.max());
    }

    @org.junit.jupiter.api.Test
    void min() {
        assertEquals(1500, a.min());    }

    @org.junit.jupiter.api.Test
    void range() {
        assertEquals(18596000, a.range());
    }

    @org.junit.jupiter.api.Test
    void mean() {
        assertEquals(1086564, a.mean());
    }

    @org.junit.jupiter.api.Test
    void median() {
        assertEquals(434500, a.median());
        assertEquals(b.median(), b.median());
    }

    @org.junit.jupiter.api.Test
    void findAccount() {
        assertEquals(a.findAccount(1111991), c.findAccount(1111991));
        assertEquals(a.findAccount(9999119), c.findAccount(9999119));

    }

    @org.junit.jupiter.api.Test
    void findAddress() {
        assertEquals(a.findAddress(1111991), c.findAddress(1111991));
        assertEquals(a.findAddress(9999119), c.findAddress(9999119));
    }

    @org.junit.jupiter.api.Test
    void findAssessedValue() {
        assertEquals(a.findAssessedValue(1111991), c.findAssessedValue(1111991));
        assertEquals(a.findAssessedValue(9999119), c.findAssessedValue(9999119));
    }

    @org.junit.jupiter.api.Test
    void findAssessmentClass() {
        assertEquals(a.findAssessmentClass(1111991), c.findAssessmentClass(1111991));
        assertEquals(a.findAssessmentClass(9999119), c.findAssessmentClass(9999119));
    }

    @org.junit.jupiter.api.Test
    void findNeighborhood() {
        assertEquals(a.findNeighborhood(1111991), c.findNeighborhood(1111991));
        assertEquals(a.findNeighborhood(9999119), c.findNeighborhood(9999119));
    }

    @org.junit.jupiter.api.Test
    void findLocation() {
        assertEquals(a.findLocation(1111991), c.findLocation(1111991));
        assertEquals(a.findLocation(9999119), c.findLocation(9999119));
    }

    @org.junit.jupiter.api.Test
    void buildNeighbor() {
        assertTrue(a.buildNeighbor("stillwater").number() > 0);
        assertTrue(a.buildNeighbor("abcd").propertyList.isEmpty());
    }

    @org.junit.jupiter.api.Test
    void buildAssess() {
        assertTrue(a.buildAssess("abcd").propertyList.isEmpty());
        assertTrue(a.buildAssess("residential").number() > 0);
    }

    @Test
    void testToString() {
        assertEquals(c.toString(), a.toString());
    }

    @Test
    void testEquals() {
        assertTrue(c.equals(c));
        assertFalse(a.equals(b));
    }

    @Test
    void testHashCode() {
        assertTrue(a.hashCode() == c.hashCode());
        assertFalse(a.hashCode() == b.hashCode());
    }
}