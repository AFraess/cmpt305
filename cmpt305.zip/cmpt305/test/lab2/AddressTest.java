package lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AddressTest {

    Address a;
    Address b;
    Address c;
    Address d;

    @BeforeEach
    void setUp() {
        a = new Address("a", "b", "c");
        b = new Address("", "b", "c");
        c = new Address("a", "", "c");
        d = new Address("a", "", "c");
    }

    @Test
    void testToString() {
        assertEquals("a b c", a.toString());
        assertEquals("b c", b.toString());
        assertEquals("a c", c.toString());
    }

    @Test
    void testEquals() {
        assertFalse(a.equals(b));
        assertTrue(c.equals(d));
    }

    @Test
    void testHashCode() {
        assertFalse(a.hashCode() == b.hashCode());
        assertTrue(c.hashCode() == d.hashCode());
    }
}