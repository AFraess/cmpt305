package lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LocationTest {

    Location l;
    Location l2;
    Location l3;
    Location l4;

    @BeforeEach
    void setUp() {
        l = new Location(1,1);
        l2 = new Location(1.69,1.99999);
        l3 = new Location(400600,10070000);
        l4 = new Location(1,1);
    }

    @Test
    void testToString() {
        assertEquals("(1.0, 1.0)", l.toString());
        assertEquals("(1.69, 1.99999)", l2.toString());
        assertEquals("(400600.0, 1.007E7)", l3.toString());
    }

    @Test
    void testEquals() {
        assertFalse(l.equals(l2));
        assertTrue(l.equals(l4));
    }

    @Test
    void testHashCode() {
        assertFalse(l.hashCode() == l2.hashCode());
        assertTrue(l.hashCode() == l4.hashCode());
        //assertTrue(l.hashCode() == l.hashCode());
    }
}