package lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NeighborhoodTest {

    Neighborhood a;
    Neighborhood b;
    Neighborhood c;

    @BeforeEach
    void setUp() {
        a = new Neighborhood("1","a","b");
        b = new Neighborhood("1","b","b");
        c = new Neighborhood("1","a","b");
    }

    @Test
    void testToString() {
        assertEquals("1 a b", a.toString());
    }

    @Test
    void testEquals() {
        assertFalse(a.equals(b));
        assertTrue(a.equals(c));
    }

    @Test
    void testHashCode() {
        assertTrue(a.hashCode() == c.hashCode());
        assertFalse(a.hashCode() == b.hashCode());
    }
}