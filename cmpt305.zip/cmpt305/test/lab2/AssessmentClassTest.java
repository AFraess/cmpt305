package lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AssessmentClassTest {

    AssessmentClass a;
    AssessmentClass b;
    AssessmentClass c;


    @BeforeEach
    void setUp() {
        a = new AssessmentClass("r","100");
        b = new AssessmentClass("r","10");
        c = new AssessmentClass("r","100");
    }

    @Test
    void testToString() {
        assertEquals("r 100%", a.toString());
        assertEquals("r 10%", b.toString());
    }

    @Test
    void testEquals() {
        assertFalse(a.equals(b));
        assertTrue(a.equals(c));
    }

    @Test
    void testHashCode() {
        assertTrue(a.hashCode() == c.hashCode());
        assertFalse(a.hashCode() == b.hashCode());
    }
}