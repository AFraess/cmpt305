package lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class PropertyAssessmentTest {

    PropertyAssessment a;
    PropertyAssessment b;
    PropertyAssessment c;

    @BeforeEach
    void setUp() throws IOException {
        PropertyAssessments d = new PropertyAssessments("Property_Assessment_Data_2026_Small.csv");
        a = d.propertyList.getFirst();
        b = d.propertyList.get(2);
        c = d.propertyList.getFirst();
    }

    @Test
    void testToString() {
        assertEquals("PropertyAssessment{accountNumber=1273614, address=14348 115 AVENUE NW, neighborhood='3230 HUFF BREMNER ESTATE INDUSTRIAL Anirniq', assessedValue=10500, taxClass='Non Residential', garage='N', assessmentClass=COMMERCIAL 100%, location=(53.56559301761956, -113.56925014047397)}", a.toString());
    }

    @Test
    void testEquals() {
        assertFalse(a.equals(b));
        assertTrue(a.equals(c));
    }

    @Test
    void testHashCode() {
        assertTrue(a.hashCode() == c.hashCode());
        assertFalse(a.hashCode() == b.hashCode());
    }
}