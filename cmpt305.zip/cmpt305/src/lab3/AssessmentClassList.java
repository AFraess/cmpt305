package lab3;

import lab2.PropertyAssessment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class AssessmentClassList {

    public List<PropertyAssessment> propertyList = new ArrayList<>();

    public AssessmentClassList(List<PropertyAssessment> nList){
        propertyList.addAll(nList);
    }

    public int number(){
        return propertyList.toArray().length;
    }

    // Find max & min propertyAssessment
    public int max(){
        int max = -1;
        for (PropertyAssessment pA : propertyList){
            int num = pA.assessedValue;
            if (max == -1){
                max = num;
            } else if (num > max){
                max = num;
            }
        }
        return max;
    }

    public int min(){
        int min = -1;
        for (PropertyAssessment pA : propertyList){
            int num = pA.assessedValue;
            if (min == -1){
                min = num;
            } else if (num < min) {
                min = num;
            }
        }
        return min;
    }

    public int range(){
        return max()-min();
    }

    public int mean(){
        long total = 0;
        for (PropertyAssessment pA : propertyList){
            total += pA.assessedValue;
        }
        return (int)((double)total/(double)number());
    }

    public  int median(){
        int[] array2 = new int[number()];
        int i = 0;
        for (PropertyAssessment pA : propertyList){
            array2[i] = pA.assessedValue;
            i++;
        }
        //sort!?
        Arrays.sort(array2);
        if (array2.length % 2 == 0){
            return(array2[(array2.length/2-1)]+array2[(array2.length/2)])/2;
        }
        return array2[(array2.length/2)];
    }

    @Override
    public String toString() {
        return "AssessmentClassList{" +
                "propertyList=" + propertyList +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        AssessmentClassList that = (AssessmentClassList) o;
        return Objects.equals(propertyList, that.propertyList);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(propertyList);
    }
}
