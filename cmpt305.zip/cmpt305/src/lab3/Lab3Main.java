package lab3;

import lab2.PropertyAssessments;

import java.io.IOException;
import java.util.Scanner;

public class Lab3Main {
    static void main(){
        // create scanner
        Scanner scanner = new Scanner(System.in);

        System.out.print("CSV Filename: ");

        String csvFilename = scanner.nextLine();
        try {
            PropertyAssessments pList = new PropertyAssessments(csvFilename);

            System.out.print("Please enter a neighborhood name: ");
            String neighborStr = scanner.nextLine();

            PropertyAssessments neighborList = pList.buildNeighbor(neighborStr);
            if (neighborList.number() > 0){
                System.out.println("There are " + neighborList.number() + " properties in " + neighborStr);
                System.out.println("The mean value is CAD " + neighborList.mean());
                System.out.println("The median value is CAD " + neighborList.median());

            } else {
                System.out.println("Sorry, cant find data in "+ neighborStr);
            }
            System.out.print("\nPlease enter an assessment class: ");
            String assessStr = scanner.nextLine();

            PropertyAssessments assessList = pList.buildAssess(assessStr);
            if (assessList.number() > 0){
                System.out.println("There are " + assessList.number() + " " + assessStr +" properties in Edmonton");
                System.out.println("The min value is CAD " + assessList.min());
                System.out.println("The max value is CAD " + assessList.max());

            } else {
                System.out.println("Sorry, cant find "+ assessStr + " properties");
            }

        } catch (java.io.IOException e){
            System.out.println("Error in opening " + csvFilename);
        }
    }
}
