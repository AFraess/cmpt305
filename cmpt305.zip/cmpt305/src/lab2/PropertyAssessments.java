package lab2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class PropertyAssessments {

    public List<PropertyAssessment> propertyList = new ArrayList<>();

    public PropertyAssessments(String csvFileName) throws IOException {


        try {
            //Fill pList
            for (String[] rows : readData(csvFileName)){
                propertyList.add(new PropertyAssessment(rows));
            }
        } catch (IOException e){
            throw new IOException();
        }

    }

    private PropertyAssessments(List<PropertyAssessment> pList) {
        propertyList = pList;
    }

    //Taken from CSV READER very lightly adapted --------------------------------------------------------------
    private static String[][] readData(String csvFileName) throws IOException {
        String[][] data;
        int currentIndex = 0;
        // Try-with-resources statement to create a stream to read the CSV file. Automatically closes the resource.
        try (BufferedReader reader = Files.newBufferedReader(Path.of(csvFileName))) {
            // Skip the header - this assumes the first line is a header
            reader.readLine();

            // Create 2D array to store all rows of data as String
            int initialSize = 100;
            data = new String[initialSize][];

            // Read the file line by line and store all rows into a 2D array
            String record;
            while ((record = reader.readLine()) != null) {
                // Parse the record into fields
                // A simple CSV line with fields that are not surrounded by double-quotes,
                // and all commas acting as separators, can be split using the String.plit() method.
                // String[] values = record.split(",");
                // Otherwise, a more general CSV parsing is required:
                String[] values = CsvParser.parseCSVLine(record);

                // Check if the array is full
                if (currentIndex == data.length)
                // Array is full, create and copy all values to a larger array
                {
                    data = Arrays.copyOf(data, data.length * 2);
                }

                data[currentIndex++] = values;
            }
        }
        // Remove empty rows in the array and return it
        return Arrays.copyOf(data, currentIndex);
    }//-----------------------------------------------------------------------------------------

    public int number(){
        return propertyList.toArray().length;
    }
    // Find max & min propertyAssessment
    public int max(){
        int max = -1;
        for (PropertyAssessment pA : propertyList){
            int num = pA.assessedValue;
            if (max == -1){
                max = num;
            } else if (num > max){
                max = num;
            }
        }
        return max;
    }
    public int min(){
        int min = -1;
        for (PropertyAssessment pA : propertyList){
            int num = pA.assessedValue;
            if (min == -1){
                min = num;
            } else if (num < min) {
                min = num;
            }
        }
        return min;
    }
    // range (max-min)
    public int range(){
        return max()-min();
    }

    // mean and median of property assessments

    public int mean(){
        long total = 0;
        for (PropertyAssessment pA : propertyList){
            total += pA.assessedValue;
        }
        return (int)((double)total/(double)number());
    }

    public  int median(){
        int[] array2 = new int[number()];
        int i = 0;
        for (PropertyAssessment pA : propertyList){
            array2[i] = pA.assessedValue;
            i++;
        }
        //sort!?
        Arrays.sort(array2);
        if (array2.length % 2 == 0){
            return(array2[(array2.length/2-1)]+array2[(array2.length/2)])/2;
        } else {
            return array2[(array2.length/2)];
        }
    }

    public boolean findAccount(int accountNum){ // returns account number
        for (PropertyAssessment rows : propertyList){
            if (accountNum == rows.accountNumber){
            return true;
            }
        }
        return false;
    }

    public Address findAddress(int accountNum){ // returns address
        for (PropertyAssessment rows : propertyList){
            if (accountNum == rows.accountNumber){
                return rows.address;
            }
        }
        return null;
    }
    public int findAssessedValue(int accountNum){ // returns assessed value
        for (PropertyAssessment rows : propertyList){
            if (accountNum == rows.accountNumber){
                return rows.assessedValue;
            }
        }
        return -1;
    }
    public List<AssessmentClass> findAssessmentClass(int accountNum){ // returns assessment class
        for (PropertyAssessment rows : propertyList){
            if (accountNum == rows.accountNumber){
                return rows.assessmentClasses;
            }
        }
        return null;
    }
    public Neighborhood findNeighborhood(int accountNum){ // returns neighborhood
        for (PropertyAssessment rows : propertyList){
            if (accountNum == rows.accountNumber){
                return rows.neighborhood;
            }
        }
        return null;
    }
    public Location findLocation(int accountNum){ //returns location
        for (PropertyAssessment rows : propertyList){
            if (accountNum == rows.accountNumber){
                return rows.location;
            }
        }
        return null;
    }
    // builds the neighbor list
    public PropertyAssessments buildNeighbor(String neighborString){

        List<PropertyAssessment> nList = new ArrayList<>();
        //Iterate to find filling
        for (PropertyAssessment rows : propertyList){
            if (rows.neighborhood.neighborhood.equalsIgnoreCase(neighborString)){
                nList.add(rows);
            }
        }
        // apply to list
        return new PropertyAssessments(nList);
    }
    // builds Assessment list
    public PropertyAssessments buildAssess (String assessString) {

        List<PropertyAssessment> aList = new ArrayList<>();
        //iterate to find filling
        for (PropertyAssessment rows : propertyList){
            for (AssessmentClass rows2 : rows.assessmentClasses){
                if (rows2.assessmentClass.equalsIgnoreCase(assessString)){
                    aList.add(rows);
                    break;
                }
            }
        }
        //apply to list
        return new PropertyAssessments(aList);
    }


    @Override
    public String toString() {
        return "PropertyAssessments{" +
                "propertyList=" + propertyList +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        PropertyAssessments that = (PropertyAssessments) o;
        return Objects.equals(propertyList, that.propertyList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(propertyList);
    }
}
