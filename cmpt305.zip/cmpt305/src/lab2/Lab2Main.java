package lab2;

import java.io.IOException;
import java.util.Scanner;

public class Lab2Main {
    public static void main(String[] args) {
        // create scanner
        Scanner scanner = new Scanner(System.in);
        System.out.print("CSV filename: ");
        // try to parse filename
        String csvFileName = scanner.nextLine();

        try { // FIRST LINE --------------------------------------------------------------------

            PropertyAssessments pList = new PropertyAssessments(csvFileName);
            //print
            System.out.println("n = " + pList.number());
            System.out.println("min = $" + pList.min());
            System.out.println("max = $" + pList.max());
            System.out.println("range = $" + pList.range());
            System.out.println("mean = $" + pList.mean());
            System.out.println("median = $" + pList.median());

            System.out.print("\nFind a property assessment by account number: ");
            try { // SECOND LINE -------------------------------------------------------------

                int accountNum = Integer.parseInt(scanner.nextLine());

                if (pList.findAccount(accountNum)){
                        System.out.println("Account Number = " + accountNum);
                        System.out.println("Address = " + pList.findAddress(accountNum));
                        System.out.println("Assessed value = $" + pList.findAssessedValue(accountNum));
                        System.out.println("Assessment class = " + pList.findAssessmentClass(accountNum));
                        System.out.println("Neighborhood = " + pList.findNeighborhood(accountNum));
                        System.out.println("Location = " + pList.findLocation(accountNum));
                } else {
                    System.out.println("Property is not found");
                }
            } catch (NumberFormatException e){
                System.out.println("Invalid account number");
            }

            System.out.print("\nFind statistics by neighborhood: ");
            //try { // THIRD LINE -----------------------------------------------------------
            String neistr = scanner.nextLine();

            PropertyAssessments neighborList = pList.buildNeighbor(neistr);
            if (neighborList.number() > 0){
                System.out.println("n = " + neighborList.number());
                System.out.println("min = $" + neighborList.min());
                System.out.println("max = $" + neighborList.max());
                System.out.println("range = $" + neighborList.range());
                System.out.println("mean = $" + neighborList.mean());
                System.out.println("median = $" + neighborList.median());
            } else {
                System.out.println("Neighborhood is not found");
            }
            //} //catch (){
            //  System.out.println("Invalid neighborhood name");
            //}

        } catch (IOException e) {
            System.err.println("Error: can't open file " + csvFileName);
        }

    }
}
