package lab2;

import package1.package1.CsvParser;
import package1.lab2.PropertyAssessment;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Lab2Main {
    public static void main(String[] args) {
        // create scanner
        Scanner scanner = new Scanner(System.in);
        System.out.print("CSV filename: ");
        String csvFileName = scanner.nextLine();
        // try to parse filename
        List<PropertyAssessment> pList = new ArrayList<>();
        try { // FIRST LINE --------------------------------------------------------------------
            //Fill pList
            for (String[] rows : readData(csvFileName)){
                pList.add(new PropertyAssessment(rows));
            }
            // Find max & min propertyAssessment
            int min = -1;
            int max = -1;
            long total = 0;
            for (PropertyAssessment pA : pList){
                int num = pA.assessedValue;
                total = total + num;
                if (max == -1 && min == -1){
                    max = num;
                    min = num;
                } else if (num > max){
                    max = num;
                } else if (num < min) {
                    min = num;
                }
            }
            //print
            System.out.println("n = " + pList.toArray().length);
            System.out.println("min = $" + min);
            System.out.println("max = $" + max);
            System.out.println("range = $" + (max-min));
            System.out.println("mean = $" + (total/pList.toArray().length));
            System.out.println("median = $" + findMedian(pList));

            System.out.print("Find a property assessment by account number: ");
            try { // SECOND LINE -------------------------------------------------------------
                int accountNum = Integer.parseInt(scanner.nextLine());
                boolean target = false;
                for (PropertyAssessment pA : pList){
                    if (accountNum == pA.accountNumber){
                        target = true;
                        System.out.println("Account Number = " + pA.accountNumber);
                        System.out.println("Address = " + pA.houseNumber + pA.street);
                        System.out.println("Assessed value = $" + pA.assessedValue);
                        System.out.println("Assessment class = [" + pA.printAssessmentClass() + "]");
                        System.out.println("Neighborhood = " + pA.neighborhood);
                        System.out.println("Location = " + pA.printLocation());
                    }
                }
                if (!target){
                    System.out.println("Property is not found");
                }
            } catch (NumberFormatException e){
                System.out.println("Invalid account number");
            }

            System.out.print("Find statistics by neighborhood: ");
            //try { // THIRD LINE -----------------------------------------------------------
            String neistr = scanner.nextLine();
            List<PropertyAssessment> nList = new ArrayList<>();
            int minN = -1;
            int maxN = -1;
            long totalN = 0;
            for (PropertyAssessment rows : pList){
                if (neistr.equalsIgnoreCase(rows.neighborhood)){
                    nList.add(rows);
                    if (minN == -1){
                        minN = rows.assessedValue;
                        maxN = rows.assessedValue;
                    } else if (rows.assessedValue > maxN) {
                        maxN = rows.assessedValue;
                    } else if (rows.assessedValue < minN) {
                        minN = rows.assessedValue;
                    }
                    totalN += rows.assessedValue;
                }
            }
            //print
            if (minN != -1){
                System.out.println("n = " + nList.toArray().length);
                System.out.println("min = $" + minN);
                System.out.println("max = $" + maxN);
                System.out.println("range = $" + (maxN-minN));
                System.out.println("mean = $" + totalN/nList.toArray().length);
                System.out.println("median = $" + findMedian(nList));

            } else {
                System.out.println("Neighborhood is not found");
            }
            //} //catch (){
            //  System.out.println("Invalid neighborhood name");
            //}

        } catch (IOException e) {
            System.err.println("Error: can't open file " + csvFileName + e);
        }

    }
    //Taken from CSV READER lightly adapted --------------------------------------------------------------
    private static String[][] readData(String csvFileName) throws IOException {
        String[][] data;
        int currentIndex = 0;
        // Try-with-resources statement to create a stream to read the CSV file. Automatically closes the resource.
        try (BufferedReader reader = Files.newBufferedReader(Path.of(csvFileName))) {
            // Skip the header - this assumes the first line is a header
            reader.readLine();

            // Create 2D array to store all rows of data as String
            int initialSize = 100;
            data = new String[initialSize][];

            // Read the file line by line and store all rows into a 2D array
            String record;
            while ((record = reader.readLine()) != null) {
                // Parse the record into fields
                // A simple CSV line with fields that are not surrounded by double-quotes,
                // and all commas acting as separators, can be split using the String.plit() method.
                // String[] values = record.split(",");
                // Otherwise, a more general CSV parsing is required:
                String[] values = CsvParser.parseCSVLine(record);

                // Check if the array is full
                if (currentIndex == data.length)
                // Array is full, create and copy all values to a larger array
                {
                    data = Arrays.copyOf(data, data.length * 2);
                }

                data[currentIndex++] = values;
            }
        }
        // Remove empty rows in the array and return it
        return Arrays.copyOf(data, currentIndex);
    }
    // created median finder --------------------------------------------------------------------
    private static int findMedian(List<PropertyAssessment> array){

        int[] array2 = new int[array.toArray().length];
        int i = 0;
        for (PropertyAssessment pA : array){
            array2[i] = pA.assessedValue;
            i++;
        }
        //sort!?
        Arrays.sort(array2);
        if (array2.length % 2 == 0){
            return(array2[(array2.length/2-1)]+array2[(array2.length/2)])/2;
        } else {
            return array2[(array2.length/2)];
        }
    }
}
