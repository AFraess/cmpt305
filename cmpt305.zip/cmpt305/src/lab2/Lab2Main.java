package lab2;

import package1.package1.CsvParser;
import lab2.PropertyAssessment;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Lab2Main {
    public static void main(String[] args) {
        // create scanner
        Scanner scanner = new Scanner(System.in);
        System.out.print("CSV filename: ");
        // try to parse filename
        String csvFileName = scanner.nextLine();

        try { // FIRST LINE --------------------------------------------------------------------

            PropertyAssessments pList = new PropertyAssessments(csvFileName);
            //print
            System.out.println("n = " + pList.number());
            System.out.println("min = $" + pList.min());
            System.out.println("max = $" + pList.max());
            System.out.println("range = $" + pList.range());
            System.out.println("mean = $" + pList.mean());
            System.out.println("median = $" + pList.median());

            System.out.print("\nFind a property assessment by account number: ");
            try { // SECOND LINE -------------------------------------------------------------

                int accountNum = Integer.parseInt(scanner.nextLine());

                if (pList.findAccount(accountNum)){
                        System.out.println("Account Number = " + accountNum);
                        System.out.println("Address = " + pList.findAddress(accountNum));
                        System.out.println("Assessed value = $" + pList.findAssessedValue(accountNum));
                        System.out.println("Assessment class = " + pList.findAssessmentClass(accountNum));
                        System.out.println("Neighborhood = " + pList.findNeighborhood(accountNum));
                        System.out.println("Location = " + pList.findLocation(accountNum));
                } else {
                    System.out.println("Property is not found");
                }
            } catch (NumberFormatException e){
                System.out.println("Invalid account number");
            }

            System.out.print("\nFind statistics by neighborhood: ");
            //try { // THIRD LINE -----------------------------------------------------------
            String neistr = scanner.nextLine();

            if (pList.buildNeighbor(neistr)){
                System.out.println("n = " + pList.neighborList.number());
                System.out.println("min = $" + pList.neighborList.min());
                System.out.println("max = $" + pList.neighborList.max());
                System.out.println("range = $" + pList.neighborList.range());
                System.out.println("mean = $" + pList.neighborList.mean());
                System.out.println("median = $" + pList.neighborList.median());
            } else {
                System.out.println("Neighborhood is not found");
            }
            //} //catch (){
            //  System.out.println("Invalid neighborhood name");
            //}

        } catch (IOException e) {
            System.err.println("Error: can't open file " + csvFileName);
        }

    }
}
