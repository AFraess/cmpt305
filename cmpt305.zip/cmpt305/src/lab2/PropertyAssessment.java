package lab2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class PropertyAssessment {

    public int accountNumber;
    public int assessedValue;

    public String taxClass;
    public String garage;

    public Address address;

    public Neighborhood neighborhood;

    public List<AssessmentClass> assessmentClasses = new ArrayList<>();

    public Location location;

    public PropertyAssessment(String[] data){
        accountNumber = Integer.parseInt(data[0]);
        assessedValue = Integer.parseInt(data[7]);
        taxClass = data[8];
        garage = data[9];

        //ADD EMPTY DETECTION?
        assessmentClasses.add(new AssessmentClass(data[10], data[13]));
        if (!data[11].isEmpty()){
            assessmentClasses.add(new AssessmentClass(data[11], data[14]));
        }
        if (!data[12].isEmpty()){
            assessmentClasses.add(new AssessmentClass(data[12], data[15]));
        }



        address = new Address(data[1], data[2], data[3]);

        neighborhood = new Neighborhood(data[4], data[5], data[6]);

        location = new Location(Double.parseDouble(data[16]), Double.parseDouble(data[17]));
    }

    @Override
    public String toString() {
        return "PropertyAssessment{" +
                "accountNumber=" + accountNumber +
                ", address=" + address +
                ", neighborhood='" + neighborhood + '\'' +
                ", assessedValue=" + assessedValue +
                ", taxClass='" + taxClass + '\'' +
                ", garage='" + garage + '\'' +
                ", assessmentClass=" + assessmentClasses.get(0) +
                ", location=" + location +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        PropertyAssessment that = (PropertyAssessment) o;
        return accountNumber == that.accountNumber && address == that.address && assessedValue == that.assessedValue && Objects.equals(neighborhood, that.neighborhood) && Objects.equals(taxClass, that.taxClass) && Objects.equals(garage, that.garage) && Objects.deepEquals(assessmentClasses, that.assessmentClasses) && Objects.deepEquals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber, address, neighborhood, assessedValue, taxClass, garage, assessmentClasses, location);
    }
}
