package package1.lab2;

import java.util.Arrays;
import java.util.Objects;

public class PropertyAssessment {

    public int accountNumber;
    public int suiteNumber;
    public int houseNumber;
    public String street;
    public int neighborhoodID;
    public String neighborhood;
    public String ward;
    public int assessedValue;
    public String taxClass;
    public String garage;
    public String[] assessmentClass = new String[3];
    public String[] assessmentClassTotals = new String[3];
    public double[] location = new double[2];

    public PropertyAssessment(String[] data){
        accountNumber = Integer.parseInt(data[0]);
        try {suiteNumber = Integer.parseInt(data[1]);} catch (NumberFormatException e){suiteNumber = -1;}
        try {houseNumber = Integer.parseInt(data[2]);} catch (NumberFormatException e){houseNumber = -1;}
        street = data[3];
        try {neighborhoodID = Integer.parseInt(data[4]);} catch (NumberFormatException e){neighborhoodID = -1;}
        neighborhood = data[5];
        ward = data[6];
        assessedValue = Integer.parseInt(data[7]);
        taxClass = data[8];
        garage = data[9];
        assessmentClass[0] = data[10];
        assessmentClass[1] = data[11];
        assessmentClass[2] = data[12];
        assessmentClassTotals[0] = data[13];
        assessmentClassTotals[1] = data[14];
        assessmentClassTotals[2] = data[15];
        location[0] = Double.parseDouble(data[16]);
        location[1] = Double.parseDouble(data[17]);
    }
    public String printLocation(){
        return "(" + location[0] + ", " + location[1] + ")";
    }
    public String printAssessmentClass(){
        String total = assessmentClass[0] + " " + assessmentClassTotals[0]+"%";
        if (!assessmentClass[1].isEmpty()){
            total += ", " + assessmentClass[1] + " " + assessmentClassTotals[1]+"%";
        }
        if (!assessmentClass[2].isEmpty()){
            total += ", " + assessmentClass[2] + " " + assessmentClassTotals[1]+"%";
        }
        return total;
    }

    @Override
    public String toString() {
        return "PropertyAssessment{" +
                "accountNumber=" + accountNumber +
                ", suiteNumber=" + suiteNumber +
                ", houseNumber=" + houseNumber +
                ", street='" + street + '\'' +
                ", neighborhoodID=" + neighborhoodID +
                ", neighborhood='" + neighborhood + '\'' +
                ", ward='" + ward + '\'' +
                ", assessedValue=" + assessedValue +
                ", taxClass='" + taxClass + '\'' +
                ", garage='" + garage + '\'' +
                ", assessmentClass=" + Arrays.toString(assessmentClass) +
                ", assessmentClassTotals=" + Arrays.toString(assessmentClassTotals) +
                ", location=" + Arrays.toString(location) +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        PropertyAssessment that = (PropertyAssessment) o;
        return accountNumber == that.accountNumber && suiteNumber == that.suiteNumber && houseNumber == that.houseNumber && neighborhoodID == that.neighborhoodID && assessedValue == that.assessedValue && Objects.equals(street, that.street) && Objects.equals(neighborhood, that.neighborhood) && Objects.equals(ward, that.ward) && Objects.equals(taxClass, that.taxClass) && Objects.equals(garage, that.garage) && Objects.deepEquals(assessmentClass, that.assessmentClass) && Objects.deepEquals(assessmentClassTotals, that.assessmentClassTotals) && Objects.deepEquals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber, suiteNumber, houseNumber, street, neighborhoodID, neighborhood, ward, assessedValue, taxClass, garage, Arrays.hashCode(assessmentClass), Arrays.hashCode(assessmentClassTotals), Arrays.hashCode(location));
    }
}
