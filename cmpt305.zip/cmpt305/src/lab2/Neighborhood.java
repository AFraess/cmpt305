package lab2;

import java.util.Objects;

public class Neighborhood {

    public Integer neighborhoodID;
    public String neighborhood;
    public String ward;

    public Neighborhood(String neighID, String neigh, String war){
        try {neighborhoodID = Integer.parseInt(neighID);} catch (NumberFormatException e){neighborhoodID = null;}
        neighborhood = neigh;
        ward = war;
    }

    @Override
    public String toString() {
        return neighborhoodID + " " + neighborhood + " " + ward;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Neighborhood that = (Neighborhood) o;
        return Objects.equals(neighborhoodID, that.neighborhoodID) && Objects.equals(neighborhood, that.neighborhood) && Objects.equals(ward, that.ward);
    }

    @Override
    public int hashCode() {
        return Objects.hash(neighborhoodID, neighborhood, ward);
    }
}
