package lab2;

import java.util.Objects;

public class AssessmentClass {

    public String assessmentClass;
    public int assessmentClassTotal;

    public AssessmentClass(String aClass, String aTotal){
        assessmentClass = aClass;
        assessmentClassTotal = Integer.parseInt(aTotal);
    }

    @Override
    public String toString() {
        return assessmentClass + " " + assessmentClassTotal + '%';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        AssessmentClass that = (AssessmentClass) o;
        return assessmentClassTotal == that.assessmentClassTotal && Objects.equals(assessmentClass, that.assessmentClass);
    }

    @Override
    public int hashCode() {
        return Objects.hash(assessmentClass, assessmentClassTotal);
    }
}
