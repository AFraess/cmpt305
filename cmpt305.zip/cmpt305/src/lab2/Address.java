package lab2;

import java.util.Objects;

public class Address {

    public String suiteNumber;
    public String houseNumber;
    public String street;

    public Address(String suiteNum, String houseNum, String streetName ){
        suiteNumber = suiteNum;
        houseNumber = houseNum;
        street = streetName;
    }

    @Override
    public String toString() {
        String line = "";
        if (!suiteNumber.isEmpty()){
            line += suiteNumber + " ";
        }
        if (!houseNumber.isEmpty()){
            line += houseNumber + " ";
        }
        line += street;
        return line;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Address that = (Address) o;
        return Objects.equals(suiteNumber, that.suiteNumber) && Objects.equals(houseNumber, that.houseNumber) && Objects.equals(street, that.street);
    }

    @Override
    public int hashCode() {
        return Objects.hash(suiteNumber, houseNumber, street);
    }
}
