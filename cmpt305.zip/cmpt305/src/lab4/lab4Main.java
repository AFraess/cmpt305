package lab4;

import lab2.PropertyAssessments;

import java.io.IOException;
import java.util.Scanner;

public class lab4Main {

    static void main() {
        // create scanner
        Scanner scanner = new Scanner(System.in);
        System.out.print("CSV filename: ");
        // store filename
        String csvString = scanner.nextLine();
        // try to make plist and everything else
        try {
            PropertyAssessments pList = new PropertyAssessments(csvString);

            System.out.println("\n");




        } catch (IOException e){ // If IOException, filename wrong
            System.err.println("Error: can't open file " + csvString);
        }
    }
}
